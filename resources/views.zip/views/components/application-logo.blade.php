
<img src="{{ url('assets/logo_wc.png') }}" width="100px" alt="welcare">

