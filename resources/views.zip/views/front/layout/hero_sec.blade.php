 <section id="hero" class="d-flex align-items-center">
    <div class="container">
      <h1>Welcare clinic</h1>
      <h2>{{ trans('web.center') }}</h2>
      <a href="#appointment" class="btn-get-started scrollto"> {{ trans('web.book_now') }}</a>
    </div>
  </section><!-- End Hero -->
