<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Welcare clinic</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="{{url('web/assets/img/favicon.ico')}}" rel="icon">
  <link href="{{url('web/assets/img/apple-touch-icon.png')}}" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.cdnfonts.com/css/tajawal" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="{{asset('web/assets/vendor/fontawesome-free/css/all.min.css')}}" rel="stylesheet">
  <link href="{{asset('web/assets/vendor/animate.css/animate.min.css')}}" rel="stylesheet">
<!--   <link href="{{asset('web/assets/vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet"> -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.rtl.min.css" integrity="sha384-+qdLaIRZfNu4cVPK/PxJJEy0B0f3Ugv8i482AKY7gwXwhaCroABd086ybrVKTa0q" crossorigin="anonymous">

<link href="{{asset('web/assets/vendor/bootstrap-icons/bootstrap-icons.css')}}" rel="stylesheet">
  <link href="{{asset('web/assets/vendor/boxicons/css/boxicons.min.css')}}" rel="stylesheet">
  <link href="{{asset('web/assets/vendor/glightbox/css/glightbox.min.css')}}" rel="stylesheet">
  <link href="{{asset('web/assets/vendor/remixicon/remixicon.css')}}" rel="stylesheet">
  <link href="{{asset('web/assets/vendor/swiper/swiper-bundle.min.css')}}" rel="stylesheet">


  <!-- Template Main CSS File -->
  <link href="{{asset('web/assets/css/style.css')}}" rel="stylesheet">

<!-- Owl Carousel -->
<link rel="stylesheet" href="{{asset('web/assets/owl-carousel/owl.carousel.min.css')}}">
<link rel="stylesheet" href="{{asset('web/assets/owl-carousel/owl.theme.default.min.css')}}">

  <style>


  </style>



  <!-- =======================================================
  * Template Name: Clinic Dylanu
  * Template URL: https://www.dylanu.com/
  * Author: Dylanu.com
  ======================================================== -->
</head>
