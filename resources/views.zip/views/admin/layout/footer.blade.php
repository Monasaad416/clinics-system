<!-- Footer opened -->
	<div class="main-footer ht-40">
		<div class="container-fluid pd-t-0-f ht-100p">
			<span>Copyright © {{ now()->year }} <a href="https://www.dylanu.com">Dylanu</a> All rights reserved.</span>
		</div>
	</div>
<!-- Footer closed -->
